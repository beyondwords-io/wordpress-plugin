<?php
/**
 * CPT Inactive
 *
 * @package           BeyondWords
 * @license           GPL-2.0-or-later
 *
 * @wordpress-plugin
 * Plugin Name:       CPT Inactive
 * Description:       Adds an valid custom post type that WILL NOT be checked during acceptance tests.
 * Version:           1.0.0
 * Text Domain:       speechkit
 * License:           GPL v2 or later
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 */

function cpt_inactive_init() {
    register_post_type('cpt_inactive', [
        'graphql_single_name' => 'cptInactivePost',
        'graphql_plural_name' => 'cptInactivePosts',
        'public'              => true,
        'label'               => 'CPT Inactive',
        'show_in_graphql'     => true,
        'show_in_rest'        => true,
        'supports'            => ['title', 'editor', 'custom-fields'],
    ]);
}
add_action('init', 'cpt_inactive_init');
