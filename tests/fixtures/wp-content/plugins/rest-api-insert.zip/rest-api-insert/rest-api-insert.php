<?php
/**
 * REST API: Insert
 *
 * @package           BeyondWords
 * @license           GPL-2.0-or-later
 *
 * @wordpress-plugin
 * Plugin Name:       REST API: Insert
 * Description:       Adds a test REST API Endpoint to insert a post.
 * Version:           1.0.0
 * Text Domain:       speechkit
 * License:           GPL v2 or later
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 */

add_action( 'rest_api_init', function () {
  register_rest_route( 'beyondwords/v3-tests', '/post/insert', array(
    'methods' => 'POST',
    'callback' => 'beyondwords_rest_api_insert',
  ), true );
} );

function beyondwords_rest_api_insert(\WP_REST_Request $request) {

    $metaInput = [];

    if (isset($request['beyondwords_generate_audio'])) {
      $metaInput['beyondwords_generate_audio'] = $request['beyondwords_generate_audio'];
    }

    if (isset($request['speechkit_generate_audio'])) {
      $metaInput['speechkit_generate_audio'] = $request['speechkit_generate_audio'];
    }

    if (isset($request['publish_post_to_speechkit'])) {
      $metaInput['publish_post_to_speechkit'] = $request['publish_post_to_speechkit'];
    }

    $result = wp_insert_post([
        'post_status' => 'publish',
        'post_title' => 'Inserted using REST API',
        'post_content' => '<p>Uses sample values from Japan Times.</p>',
        'meta_input' => $metaInput,
    ], true, true);

    if (is_wp_error($result)) {
        return $result;
    }

    $response = [
      'post_id' => $result,
    ];

    return new WP_REST_Response( $response, 200 );
}